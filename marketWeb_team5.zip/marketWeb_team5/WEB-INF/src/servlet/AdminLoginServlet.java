package servlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import dao.AdminDAO;
import bean.Admin;

public class AdminLoginServlet extends HttpServlet {

	public void doPost(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		//エラー用変数
		String error = null;
		String cmd = null;

		//AdminDAOをオブジェクト化
		AdminDAO objDao = new AdminDAO();

		//Sessionオブジェクトの宣言
		HttpSession session = request.getSession();

		//Adminオブジェクトの宣言
		Admin admin = new Admin();

		//文字エンコーディングの設定
		request.setCharacterEncoding("UTF-8");

		//入力パラメータの取得
		String name = request.getParameter("name");
		String password = request.getParameter("password");

		try {

			//メソッドを呼び出し
			admin = objDao.selectByAdmin(name,password);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、ログインできません。";
			cmd = "logout";
		}finally {
			//admin情報の有無でフォワード先を分ける
			if(admin.getName() != null) {
				//セッションスコープに登録
				session.setAttribute("admin",admin);

				//管理者用クッキーの生成
				Cookie nameCookie = new Cookie("name",name);
				nameCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(nameCookie);

				//パスワード用クッキーの生成
				Cookie passCookie = new Cookie("password",password);
				passCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(passCookie);

				//adminMenu.jspにフォワード
				request.getRequestDispatcher("/view/adminMenu.jsp").forward(request, response);

			}else {
				//リクエストスコープに登録
				request.setAttribute("message","入力データが間違っています！");

				//adminLogin.jspにフォワード
				request.getRequestDispatcher("/view/adminLogin.jsp").forward(request, response);
			}
		}
	}
}

package servlet;

import bean.Sell;
import bean.User;
import bean.Images;
import dao.SellDAO;
import dao.UserDAO;
import dao.ImagesDAO;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ItemListServlet extends HttpServlet {

	public void doGet(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

		String error ="";

		try {

			//ユーザー情報の登録
			HttpSession session = request.getSession();
			User user = (User)session.getAttribute("user");
			int userid = user.getUserid();

			//DAOクラスのオブジェクト
			SellDAO objDao = new SellDAO();
			ImagesDAO objImg = new ImagesDAO();

			//データベースの情報を格納するArrayList
			ArrayList<Sell> list = new ArrayList<Sell>();
			ArrayList<Images> img_list = new ArrayList<Images>();

			//listにデータベースの情報を格納
			list = objDao.selectByUserid(userid);
			img_list = objImg.selectAll();

			//リクエストスコープに登録
			request.setAttribute("sell_list", list);
			request.setAttribute("img_list", img_list);

			ArrayList<Sell> lists = objDao.selectByUserid(userid);

			//リクエストスコープに登録
			request.setAttribute("lists",lists);

		}catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			request.setAttribute("cmd", "logout");
		}catch (Exception e) {
			error="予期せぬエラーが発生しました";
		}finally {
			//リクエストスコープに登録
			request.setAttribute("error", error);
			if (error.equals("")) {
				//sellList.jspにフォワード
				request.getRequestDispatcher("/view/itemList.jsp").forward(request, response);
			}else {
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}


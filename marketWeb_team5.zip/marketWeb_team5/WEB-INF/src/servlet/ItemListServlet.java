package servlet;

import javax.servlet.http.HttpServlet;

public class ItemListServlet extends HttpServlet {

}

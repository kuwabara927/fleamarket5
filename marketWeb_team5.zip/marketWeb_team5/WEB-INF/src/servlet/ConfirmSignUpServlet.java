package servlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import bean.User;
import dao.UserDAO;
public class ConfirmSignUpServlet extends HttpServlet {

	public void doGet(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

		//エラー用変数
		String error = null;
		String cmd = null;

		try {

			//文字エンコーディングの設定
			request.setCharacterEncoding("UTF-8");

			//DTOオブジェクトの宣言
			User user = new User();

			//DAOオブジェクト宣言
			UserDAO objDao = new UserDAO();

			//パラメータを取得する
			String name = request.getParameter("name");
			String nickname = request.getParameter("nickname");
			String password = request.getParameter("password");
			String address = request.getParameter("address");
			String mailaddress = request.getParameter("mailaddress");

			if(name.equals("")) {
				error = "名前が未入力の為、登録処理は行えません。";
				cmd = "login";
				return;
			}
			if(nickname.equals("")) {
				error = "ニックネームが未入力の為、登録処理は行えません。";
				cmd = "login";
				return;
			}
			if(password.equals("")) {
				error = "パスワードが未入力の為、登録処理は行えません。";
				cmd = "login";
				return;
			}
			if(address.equals("")) {
				error = "住所が未入力の為、登録処理は行えません。";
				cmd = "login";
				return;
			}
			if(mailaddress.equals("")) {
				error = "メールアドレスが未入力の為、登録処理は行えません。";
				cmd = "login";
				return;
			}

			//userオブジェクトに各データを格納
			user.setName(name);
			user.setNickname(nickname);
			user.setPassword(password);
			user.setAddress(address);
			user.setMailaddress(mailaddress);

			//登録メソッドの呼び出し
			objDao.insert(user);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、登録処理は行えませんでした。";
			cmd = "login";
		}catch(Exception e) {
			error = "予期せぬエラーの為、登録処理は行えませんでした。";
			cmd = "login";
		}finally {
			//エラーがない場合
			if(error == null) {
				request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);
			}else {
				request.setAttribute("error",error);
				request.setAttribute("cmd",cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}

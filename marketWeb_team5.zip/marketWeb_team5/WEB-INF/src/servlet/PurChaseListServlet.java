package servlet;

/*
 * プログラム名： PurchaseListServlet
 * プログラムの説明：購入履歴表示機能を実装するサーブレット
 * 作成者：吉部真央
 * 作成日：2023/6/22
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.ArrayList;

import bean.Images;
import bean.Images;
import bean.Sell;
import bean.User;
import dao.ImagesDAO;
import dao.SellDAO;

public class PurchaseListServlet extends HttpServlet {

	public void doGet (HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException {

		String error = "";

		try {
			// ログインしているユーザーをセッションスコープから取得
			HttpSession session = request.getSession();
			User user = (User)session.getAttribute("user");

			// ログインユーザーのIDを取得
			int userid = user.getUserid();

			// DAOクラスのオブジェクト作成
			SellDAO sellDAO = new SellDAO();
			ImagesDAO imgDAO = new ImagesDAO();

			// リスト
			ArrayList<Sell> purchase_list = new ArrayList<Sell>();
			ArrayList<Images> img_list = new ArrayList<Images>();

			// リストに購入済商品情報を格納
			purchase_list = sellDAO.selectPurchase(userid);
			img_list = imgDAO.selectAll();

			// リクエストスコープに登録
			request.setAttribute("purchase_list", purchase_list);
			request.setAttribute("img_list", img_list);

		} catch (IllegalStateException e) { // DBエラーが起きた場合
			error = "DB接続エラーが発生した為、購入履歴を表示できません。";

		} catch (Exception e) { // 予期せぬエラーが起きた場合
			error = "予期せぬエラーが発生した為、購入履歴を表示できません。";

		} finally { // フォワード処理

			// エラーの有無
			if (error.equals("")) {	// エラーがない場合
				// PurchaseList.jspへフォワード
				request.getRequestDispatcher("/view/purchaseList.jsp").forward(request, response);

			} else { // エラーがある場合
				// リクエストスコープに登録
				request.setAttribute("error", error);

				// error.jspにフォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
package servlet;

/* (作成途中)
 * プログラム名： PurchaseListServlet
 * プログラムの説明：購入履歴表示機能を実装するサーブレット
 * 作成者：吉部真央
 * 作成日：2023/6/22
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.ArrayList;
import bean.Sell;
import bean.User;

public class PurChaseListServlet extends HttpServlet {

	public void doGet (HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException {

		String error = "";
		String cmd = "";

		try {
			ArrayList<Sell> list = new ArrayList<Sell>();

			// ログインしているユーザーをセッションスコープから入手
			HttpSession session = request.getSession(true);
			User user = (User)session.getAttribute("user");

			String id = user.getUserid();

			// 購入状況から取引完了のデータを書き出す
			// その中からセッション登録IDと購入IDが同じものを検索
			// 同じ出品IDから商品情報入手

			//引数出品ID　戻り値出品情報
			//画像は画像テーブル

			// BuyinfoからログインユーザーIDと一致する購入IDをもつ、出品物のIDを入手

			// sellinfoからその出品IDをもつ、商品情報をリストから検索

			// リクエストスコープに登録
			request.setAttribute("purchase_list", list);

		} catch (IllegalStateException e) { // DBエラーが起きた場合、エラーとコマンドを設定
			error = "DB接続エラーの為、購入履歴を表示できません。";
			cmd = null;

		} catch (Exception e) { // 予期せぬエラーが起きた場合
			error = null;

		} finally { // フォワード処理

			// エラーの有無
			if (error.equals("")) {	// エラーがない場合
				// PurchaseList.jspへフォワード
				request.getRequestDispatcher("/view/PurchaseList.jsp").forward(request, response);

			} else { // エラーがある場合
				// リクエストスコープに登録
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);

				// error.jspにフォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
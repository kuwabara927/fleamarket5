package servlet;

import javax.servlet.http.HttpServlet;

public class AdminSellListServlet extends HttpServlet {

}

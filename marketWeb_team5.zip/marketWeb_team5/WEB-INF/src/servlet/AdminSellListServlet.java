package servlet;

import bean.Sell;
import bean.User;
import bean.Buy;
import dao.SellDAO;
import dao.UserDAO;
import dao.BuyDAO;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AdminSellListServlet extends HttpServlet{

	public void doGet(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

		String error ="";
		String userid = request.getParameter("userid");
		String status = request.getParameter("status");
		if(userid == null) {
			userid = "";
		}
		if(status == null) {
			status = "";
		}

		try {
			//DAOクラスのオブジェクト
			UserDAO objUser = new UserDAO();
			SellDAO objDao = new SellDAO();
			BuyDAO objBuy = new BuyDAO();

			//データベースの情報を格納するArrayList
			ArrayList<User> user_list = new ArrayList<User>();
			ArrayList<Sell> list = new ArrayList<Sell>();
			ArrayList<Buy> buy_list = new ArrayList<Buy>();

			if(userid.equals("") && status.equals("")) {
				//listにデータベースの情報を格納
				list = objDao.selectAll();
			}else {
				list = objDao.search(userid,status);
			}
			user_list = objUser.selectAll();
			buy_list = objBuy.selectAll();
			//リクエストスコープに登録
			request.setAttribute("sell_list", list);
			request.setAttribute("user_list", user_list);
			request.setAttribute("buy_list", buy_list);
		}catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			request.setAttribute("cmd", "logout");
		}catch (Exception e) {
			error="予期せぬエラーが発生しました";
		}finally {
			//リクエストスコープに登録
			request.setAttribute("error", error);
			if (error.equals("")) {
				//sellList.jspにフォワード
				request.getRequestDispatcher("/view/adminSellList.jsp").forward(request, response);
			}else {
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
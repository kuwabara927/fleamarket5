/*
 * 瀧野仁貴
 * 20230622作成
 * 未完成です！
 */

 package servlet;


import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

public class UserInfoServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		// ①BookDAOクラスのオブジェクトを生成
		BookDAO bookDao = new BookDAO();

		// ②表示する書籍情報を格納するBookオブジェクトを生成
		Book book = new Book();

		// ③画面から送信されるISBNとcmd情報を受け取るためのエンコードを設定
		request.setCharacterEncoding("UTF-8");

		// ④画面から送信されるISBNとcmd情報を受け取る
		String isbn = request.getParameter("isbn");
		String cmd = request.getParameter("cmd");

		try {

			// ⑤BookDAOクラスに定義したselectByIsbn（）メソッドを利用して書籍情報を取得しbookオブジェクトに格納
			book = bookDao.selectByIsbn(isbn);

			if (book.getIsbn() == null) {
				error = "表示対象の書籍が存在しない為、詳細情報は表示できませんでした。";
				cmd = "list";
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

			// ⑥取得した書籍情報を「book」という名前でリクエストスコープに登録
			request.setAttribute("book", book);

			// ⑦cmd情報の値を判定し、「detail」の場合は「detail.jsp」へフォワード 階層が違うため、viewをつけ忘れない
			if (cmd.equals("detail")) {
				request.getRequestDispatcher("/view/detail.jsp").forward(request, response);
			}
			if (cmd.equals("update")) {
				request.getRequestDispatcher("/view/update.jsp").forward(request, response);
			}

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、書籍詳細は表示できませんでした。";
			cmd = "menu";
		} finally {
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);

		}

	}
}

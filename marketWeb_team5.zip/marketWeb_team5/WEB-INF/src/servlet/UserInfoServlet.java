/*
 * 瀧野仁貴
 * 20230622作成
 * 遷移元のメニュー画面さえいじれば完成出来てると思います！
 */

package servlet;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class UserInfoServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";

		// DAOクラスのオブジェクト
		UserDAO userDao = new UserDAO();

		// エンコードを設定
		request.setCharacterEncoding("UTF-8");

		String cmd = request.getParameter("cmd");

		try {

			// セッションオブジェクトの生成
			HttpSession session = request.getSession();
			// セッションスコープに登録
			User user = (User) session.getAttribute("user");
			request.setAttribute("user", user);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー詳細は表示できませんでした。";
			cmd = "menu";

		} finally {

			if (error.equals("")) {

				if(cmd.equals("userInfo")){
				request.getRequestDispatcher("/view/userInfo.jsp").forward(request, response);
				}
				if(cmd.equals("userUpdate")){
					request.getRequestDispatcher("/view/userUpdate.jsp").forward(request, response);
				}

			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}


	}
}

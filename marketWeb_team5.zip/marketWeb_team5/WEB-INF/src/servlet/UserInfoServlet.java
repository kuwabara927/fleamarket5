package servlet;

import javax.servlet.http.HttpServlet;

public class UserInfoServlet extends HttpServlet {

}

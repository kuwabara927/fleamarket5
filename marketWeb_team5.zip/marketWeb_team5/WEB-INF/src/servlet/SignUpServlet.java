package servlet;

import javax.servlet.http.HttpServlet;

public class SignUpServlet extends HttpServlet {

}

package servlet;

/*
 * 山内里桃 6/23
 */

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import bean.User;
import dao.SellDAO;

public class TotalSalesServlet extends HttpServlet {
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		//エラー用変数
		String error = null;
		String cmd = null;
		int total = 0;

		try {

			//文字エンコーディングの設定
			request.setCharacterEncoding("UTF-8");

			//DAOオブジェクト宣言
			SellDAO sellDao = new SellDAO();

			//パラメータを取得する
			int month =Integer.parseInt(request.getParameter("month"));

			//登録メソッドの呼び出し
			total = sellDao.total(month);

			request.setAttribute("month",month);
			request.setAttribute("total",total);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、登録処理は行えませんでした。";
			cmd = "login";
		}catch(Exception e) {
			error = "予期せぬエラーの為、登録処理は行えませんでした。";
			cmd = "login";
		}finally {
			//エラーがない場合
			if(error == null) {
				request.getRequestDispatcher("/view/totalSales.jsp").forward(request, response);
			}else {
				request.setAttribute("error",error);
				request.setAttribute("cmd",cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}

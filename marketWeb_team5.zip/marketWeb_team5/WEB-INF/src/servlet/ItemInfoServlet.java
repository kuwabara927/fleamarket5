package servlet;

import javax.servlet.http.HttpServlet;

public class ItemInfoServlet extends HttpServlet {

}

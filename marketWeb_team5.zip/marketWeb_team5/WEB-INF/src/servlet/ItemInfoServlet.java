package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.Sell;
import bean.User;
import dao.SellDAO;

public class ItemInfoServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException {

		// 商品IDを取得
		request.setCharacterEncoding("UTF-8");
		// int sellid = (int)request.getAttribute("sellid");
		//ざんてい処理
		int sellid =2;

		// ログインしているユーザーをセッションスコープから取得
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("user");
		request.setAttribute("user", user);

		// エラー用変数
		String error = "";

		try {
			// DAOクラスのオブジェクトを生成
			SellDAO sellDao = new SellDAO();

			// IDから商品情報を検索
			Sell sell = sellDao.selectBySellid(sellid);

			// 商品の存在をチェック
			//if(sell.getItemname == null) {
			//	error = "表示対象の商品が存在しない為、詳細情報は表示できませんでした。";
			//return;
			// }

			// 検索結果をスコープに登録
			request.setAttribute("sell", sell);

		} catch (IllegalStateException e) { // DBエラーが起きた場合
			error = "DB接続エラーの為、詳細は表示できませんでした。";

		} finally { // フォワード処理

			// エラーの有無
			if (error.equals("")) {	// エラーがない場合
					request.getRequestDispatcher("/view/itemInfo.jsp").forward(request, response);

			} else { // エラーがある場合
			// リクエストスコープに登録
			request.setAttribute("error", error);

			// error.jspにフォワード
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
package servlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.util.*;
import bean.User;
import dao.UserDAO;

public class UserListServlet extends HttpServlet {

	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		String error = null;
		String cmd = null;

		try {

			//配列宣言
			ArrayList<User> userList = new ArrayList<User>();

			//オブジェクト宣言
			UserDAO objDao = new UserDAO();

			//全検索メソッドの呼び出し
			userList = objDao .selectAll();

			//リクエストスコープに登録
			request.setAttribute("userList",userList);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示はできません";
			cmd = "logout";
		}finally {
			if(error == null) {
				request.getRequestDispatcher("/view/userList.jsp").forward(request,response);
			}else {
				request.setAttribute("error",error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}

package servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class LogoutServlet extends HttpServlet {

	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		//セッション情報をクリアする
		HttpSession session = request.getSession();
		session.invalidate();

		//login.jspにフォワード
		request.getRequestDispatcher("/view/login.jsp").forward(request, response);
	}
}

/*
 * 作成者：前田 海輝
 * 作成日：2023年6月23日
 */
package servlet;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bean.Images;
import dao.ImagesDAO;
import bean.Sell;
import dao.SellDAO;

public class ItemUpdateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String error = "";
	String cmd = "";
	try {

		// 入力データの文字コード指定
		request.setCharacterEncoding("UTF-8");
		// 入力データの取得
		String itemname = request.getParameter("itemname");
		String strCategoryid = request.getParameter("categoryid");
		String strQuantity = request.getParameter("quantity");
		String strPrice = request.getParameter("price");
		String remarks = request.getParameter("remarks");

		//写真の取得
		String strImageid = request.getParameter("imageid");

		// 1.取得したパラメータの各エラーチェックを行う
		// 1-①全データ空白チェック(title,price)
		if (itemname.equals("")) {
			error = "タイトルが未入力の為、書籍更新処理は行えませんでした。";
			cmd = "list";
			return;
		} else if (strCategoryid.equals("")) {
			error = "価格が未入力の為、書籍更新処理は行えませんでした。";
			cmd = "list";
			return;
		} else if (strQuantity.equals("")) {
			error = "価格が未入力の為、書籍更新処理は行えませんでした。";
			cmd = "list";
			return;
		} else if (strPrice.equals("")) {
			error = "価格が未入力の為、書籍更新処理は行えませんでした。";
			cmd = "list";
			return;
		} else if (remarks.equals("")) {
			error = "価格が未入力の為、書籍更新処理は行えませんでした。";
			cmd = "list";
			return;
		} else if (strCategoryid.equals("")) {
			error = "価格が未入力の為、書籍更新処理は行えませんでした。";
			cmd = "list";
			return;
		}

		// BookDAOクラスのオブジェクトを生成します。
		SellDAO sellDAO = new SellDAO();

		// 入力データの取得その２
		int categoryid = Integer.parseInt(request.getParameter("categoryid"));
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		int price = Integer.parseInt(request.getParameter("price"));
		int imageid = Integer.parseInt(request.getParameter("imageid"));

		// 画面からの入力情報を受け取り、Bookオブジェクトに格納。
		Sell sell = new Sell();
		Images image = new Images();
		sell.setItemname(itemname);
		sell.setCategoryid(categoryid);
		sell.setQuantity(quantity);
		sell.setPrice(price);
		image.setImageid(imageid);

		// 変更対象の書籍が存在しない
		if (sell.getItemname() == null) {
			error = "更新対象の書籍が存在しない為、書籍更新処理は行えませんでした。";
			cmd = "list";
		}

		// BookDAOクラスに定義したinsert()メソッド、書籍データをデータベース登録。
		sellDAO.update(sell);

		// 価格が数値以外
	} catch (NumberFormatException e) {
		error = "価格の値が不正の為、書籍更新処理は行えませんでした。";
		cmd = "list";

	} catch (IllegalStateException e) {
		error = "DB接続エラーの為、書籍更新処理は行えませんでした。";
		cmd = "logout";

	} finally {
		// エラーが空白、つまり正常
		if (error.equals("")) {
			request.getRequestDispatcher("/itemUpdate").forward(request, response);
			// error.jspへ遷移
		} else {
			request.setAttribute("cmd", cmd);
			request.setAttribute("error", error);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);

		}

	}
}
}


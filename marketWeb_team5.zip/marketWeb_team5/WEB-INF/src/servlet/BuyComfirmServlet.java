package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.Buy;
import bean.Sell;
import bean.User;

import dao.SellDAO;
import dao.BuyDAO;
import dao.UserDAO;

public class BuyComfirmServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException {

		String error = "";

		try {

			// リクエストスコープから商品と購入ユーザー情報を取得
			request.setCharacterEncoding("UTF-8");
			Sell sell  = (Sell) request.getAttribute("sell");
			User user = (User)request.getAttribute("user");

			// DAOオブジェクト作成
			BuyDAO buyDAO = new BuyDAO();
			UserDAO userDAO = new UserDAO();

			// sellidを取得(出品)
			int sellid = sell.getSellid();

			//useridとそのニックネームを取得(購入)
			int userid = user.getUserid();

			// 購入処理を行う
			buyDAO.buy(sellid,userid);

			// 出品物の情報を入手：商品名、価格
			String Itemname = sell.getItemname();
			int price = sell.getPrice();

			// 出品者の情報を入手：sellerid、ニックネーム、メールアドレス
			User seller = userDAO.selectByUser(sellid);
			int sellerid = sell.getSellerid();
			String sellname = seller.getNickname();
			String Mailaddress = seller.getMailaddress();

			// 購入者の情報を入手：ニックネーム
			String buyname = user.getNickname();

			//メール送信処理(商品情報、出品ユーザー情報、購入ユーザー情報)

			// リクエストスコープに登録
			request.setAttribute("sell",sell);;

	} catch (IllegalStateException e) { // DBエラーが起きた場合
		error = "DB接続エラーの為、詳細は表示できませんでした。";

	} finally { // フォワード処理

		// エラーの有無
		if (error.equals("")) {	// エラーがない場合
				request.getRequestDispatcher("/view/itemInfo.jsp").forward(request, response);

		} else { // エラーがある場合
		// リクエストスコープに登録
		request.setAttribute("error", error);

		// error.jspにフォワード
		request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}
	}
}
}
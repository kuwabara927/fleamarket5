package servlet;

import bean.User;
import dao.UserDAO;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet{

	public void doPost(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

		String error = "";
		String mailaddress = request.getParameter("mailaddress");
		String password = request.getParameter("pass");

		try {

			//DAOクラスのオブジェクト
			UserDAO objDao = new UserDAO();
			//DTIクラスのオブジェクト
			User user = new User();

			// データが存在するか確認
			user = objDao.selectByUser(mailaddress, password);
			if(user.getUserid() == 0) {
				error = "入力データが間違っています!";
				System.out.println(error);
				return;
			}

			// セッションオブジェクトの生成
			HttpSession session = request.getSession();
			// セッションスコープに登録
			session.setAttribute("user",user);

			// クッキーオブジェクトの生成
			//ユーザーID用
//			Cookie userCookie = new Cookie("userid",userid);
//			userCookie.setMaxAge(60 * 60* 24 * 5);
//			response.addCookie(userCookie);
			//パスワード用
//			Cookie passwordCookie = new Cookie("password",password);
//			passwordCookie.setMaxAge(60 * 60* 24 * 5);
//			response.addCookie(passwordCookie);

		}catch (IllegalStateException e) {
			error = "DB接続エラーの為、ログインは出来ません";
			request.setAttribute("cmd", "logout");
			request.setAttribute("error", error);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);
			}else {
				//存在しない場合
				request.setAttribute("message", error);
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			}
		}
	}
}
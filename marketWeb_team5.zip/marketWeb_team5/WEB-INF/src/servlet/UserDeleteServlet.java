package servlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import dao.UserDAO;

public class UserDeleteServlet extends HttpServlet {

	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		//エラー用変数
		String error = null;

		try {

			//文字エンコーディングの設定
			request.setCharacterEncoding("UTF-8");

			//パラメーターの取得
			int userid = Integer.parseInt(request.getParameter("userid"));

			//DAOオブジェクトの作成
			UserDAO objDao = new UserDAO();

			//削除メソッド
			objDao.delete(userid);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、削除できませんでした。";
		}catch(Exception e) {
			error = "予期せぬエラーが発生しました。";
		}finally {
			if(error == null) {
				request.getRequestDispatcher("/view/adminMenu.jsp").forward(request, response);
			}else {
				request.setAttribute("error",error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}

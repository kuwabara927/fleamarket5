/*商品登録機能
 * 6月23日
 * 片山葉月
 *
 * 日付、出品者、画像の実装はできていません
 */


package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Sell;
import dao.SellDAO;

public class InsertItemServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {
			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");



			//パラメータの取得
			String itemname = request.getParameter("itemname");//商品名
			int categoryid = Integer.parseInt(request.getParameter("categoryid"));//種類
			int quantity = Integer.parseInt(request.getParameter("quantity"));//個数
			int price = Integer.parseInt(request.getParameter("price"));//価格
			String remarks = request.getParameter("remarks");//備考

			//SellDaoオブジェクト生成
			SellDAO objDao = new SellDAO();



			//DTOオブジェクトを生成してメソッドを呼び出す
			Sell sell = new Sell();
			sell.setItemname(itemname);
			sell.setCategoryid(categoryid);
			sell.setQuantity(quantity);
			sell.setPrice(price);
			sell.setRemarks(remarks);

			//インサートメソッドを呼び出す
			objDao.insert(sell);




		}catch (NumberFormatException e) {
			error = "";
			return;

		}finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/sellList").forward(request, response);

			}
		}
	}
}

package servlet;

import javax.servlet.http.HttpServlet;

public class SearchServlet extends HttpServlet {

}

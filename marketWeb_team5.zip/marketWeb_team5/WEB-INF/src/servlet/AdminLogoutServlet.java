package servlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class AdminLogoutServlet extends HttpServlet {

	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		//セッション情報をクリアする
				HttpSession session = request.getSession();
				session.invalidate();

				//login.jspにフォワード
				request.getRequestDispatcher("/view/adminLogin.jsp").forward(request, response);
	}
}

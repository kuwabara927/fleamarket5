/*
 * 瀧野仁貴
 * 20230622作成
 * 未完成です！
 */

package servlet;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

public class UserUpdateServlet extends HttpServlet {

	// 書籍登録機能実装のdoGetメソッドを定義
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		// ①BookDAOクラスのオブジェクトを生成
		BookDAO bookDao = new BookDAO();

		// ②更新後書籍情報を格納するBookオブジェクトbookを生成
		Book book = new Book();

		// ③画面からの入力情報を受け取るためのエンコードを設定
		request.setCharacterEncoding("UTF-8");

		// ④画面からの入力情報を3つ受け取り、Bookオブジェクトbookに格納
		String inputIsbn = request.getParameter("isbn");
		String inputTitle = request.getParameter("title");
		// inputPriceのみ、int型だがString型で入力の値を取ってくる
		String inputPrice = request.getParameter("price");

		try {
			// ここのselectByIsbnで、削除されていた場合、bookの各値にnullが入る
			book = bookDao.selectByIsbn(inputIsbn);
			if (book.getIsbn() == null) {
				error = "更新対象の書籍が存在しない為、書籍更新処理は行えませんでした。";
				cmd = "list";
				return;
			}

			if (inputTitle.equals("")) {
				error = "タイトルが未入力の為、書籍更新処理は行えませんでした。";
				cmd = "list";
			}
			try {
				Integer.parseInt(inputPrice);

			} catch (NumberFormatException e) {

				error = "価格が不正の為、書籍更新処理は行えませんでした。";
				cmd = "list";
			}
			if (inputPrice.equals("")) {
				error = "価格が未入力の為、書籍更新処理は行えませんでした。";
				cmd = "list";
			}

			// エラーがない時
			if (error.equals("")) {
				book.setIsbn(inputIsbn);
				book.setTitle(inputTitle);
				book.setPrice(Integer.parseInt(inputPrice)); // int型に変換

				// ⑤BookDAOクラスに定義したinsert（）メソッドを利用して、Bookオブジェクトに格納された書籍データをデータベースに登録
				bookDao.update(book);

				// ⑥フォワードを行う
				request.getRequestDispatcher("/list").forward(request, response);
			}

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、書籍更新処理は行えませんでした。";
			cmd = "menu";

		} finally {

			if (!error.equals("")) {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}

}

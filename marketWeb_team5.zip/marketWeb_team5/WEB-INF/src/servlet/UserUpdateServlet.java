package servlet;

import javax.servlet.http.HttpServlet;

public class UserUpdateServlet extends HttpServlet {

}

/*
 * 瀧野仁貴
 * 20230623作成
 */

package servlet;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class UserUpdateServlet extends HttpServlet {

	// ユーザー更新機能実装のdoGetメソッドを定義
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";

		// DAOクラスのオブジェクト
		UserDAO userDao = new UserDAO();

		// 表示するユーザー情報が格納されているuserオブジェクト
		User user = new User();

		// エンコードを設定
		request.setCharacterEncoding("UTF-8");

		// 画面からの入力情報を受け取り、オブジェクトuserに格納
		String inputUserid = request.getParameter("userid");
		String inputName = request.getParameter("name");
		String inputNickname = request.getParameter("nickname");
		String inputAddress = request.getParameter("address");
		String inputMailaddress = request.getParameter("mailaddress");
		String inputPassword = request.getParameter("password");

		String cmd = request.getParameter("cmd");
		try {
			user = userDao.selectByUser(inputUserid);

			user.setUserid(Integer.parseInt(inputUserid));
			user.setName(inputName);
			user.setNickname(inputNickname);
			user.setAddress(inputAddress);
			user.setMailaddress(inputMailaddress);
			user.setPassword(inputPassword);

			// DAOクラスに定義したメソッドを利用して、Userに格納されたユーザーデータをDBに登録
			userDao.update(user);

			// セッションオブジェクトの生成
			HttpSession session = request.getSession();
			// セッションスコープに登録
			session.setAttribute("user", user);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、登録変更処理は行えませんでした。";
			cmd = "userMenu";

		} finally {

			if (error.equals("")) {
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/userInfo").forward(request, response);

			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}

}

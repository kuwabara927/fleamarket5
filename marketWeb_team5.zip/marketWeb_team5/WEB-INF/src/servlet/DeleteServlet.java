package servlet;

import javax.servlet.http.HttpServlet;

public class DeleteServlet extends HttpServlet {

}

package servlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import dao.SellDAO;
import bean.Sell;

public class DeleteServlet extends HttpServlet {

	public void doGet(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

		//エラー用変数
		String error = null;
		String cmd = null;

		try {

			//文字エンコーディングの設定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			int sellid = Integer.parseInt(request.getParameter("sellid"));

			//SellDAOオブジェクトの宣言
			SellDAO objDao = new SellDAO();

			//削除対象の書籍が存在しなかった場合
			Sell sell = objDao.selectBySellid(sellid);
			if(sell.getSellid() == 0) {
				error = "削除対象が存在しない為、削除処理は行えませんでした。";
				cmd = "list";
			}

			//削除メソッドの呼び出し
			objDao.delete(sellid);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、削除処理は行えませんでした。";
			cmd = "logout";
		}finally {
			if(error == null) {
				request.getRequestDispatcher("/view/adminMenu.jsp").forward(request, response);
			}else {
				request.setAttribute("error",error);
				request.setAttribute("cmd",cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request,response);
			}
		}
	}
}


package servlet;

import javax.servlet.http.HttpServlet;

public class TradeServlet extends HttpServlet {

}

package util;

import java.text.NumberFormat;

public class MyFormat {

	public String moneyFormat(int price) {

		// price始まりで String文字列終わり
		NumberFormat nfCur = NumberFormat.getCurrencyInstance();// 通貨形式
		String money = nfCur.format(price);

		return money;

	}

}
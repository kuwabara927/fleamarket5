package dao;

import java.sql.*;
import java.util.ArrayList;
import bean.User;

public class UserDAO {

	// 接続用の情報をフィールドに定数として定義
	public static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	public static String URL = "jdbc:mysql://localhost/fleadb";
	public static String USER = "root";
	public static String PASSWD = "root123";

	// データベースに接続するメソッド
	private static Connection getConnection(){
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// 指定ユーザとパスワードの条件に合致する情報を取得するメソッド
	public User selectByUser(String mail ,String password) {

		Connection con = null;
		Statement smt = null;

		User user = new User();

		String sql = "SELECT * FROM userinfo WHERE mailaddress = '" + mail + "' AND password='" + password + "'";

		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()) {
				user.setUserid(rs.getInt("userid"));
				user.setName(rs.getString("password"));
				user.setNickname(rs.getString("nickname"));
				user.setPassword(rs.getString("password"));
				user.setAddress(rs.getString("address"));
				user.setMailaddress(rs.getString("mailaddress"));
			}

		}catch(SQLException e) {
			System.out.println("Errorが発生しました" + e);
		}finally {
			if (smt != null) {
				try {smt.close();}catch(SQLException ignore){}
			}
			if (con != null) {
				try {con.close();}catch(SQLException ignore){}
			}
		}
		return user;
	}
	//データベースから全てのアカウント情報の検索を行うメソッド
	//戻り値としてArrayList<User>型の変数を利用
	public ArrayList<User>selectAll(){

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//return用オブジェクトの作成
		ArrayList<User> userList = new ArrayList<User>();

		//SQL文
		String sql = "SELECT * FROM userinfo ORDER BY userid";

		try {

			con = getConnection();
			smt = con.createStatement();

			//SQLをDBへ発行
			ResultSet rs = smt.executeQuery(sql);

			//検索結果を配列に格納
			while(rs.next()) {
				User user = new User();
				user.setUserid(rs.getInt("userid"));
				user.setName(rs.getString("name"));
				user.setNickname(rs.getString("nickname"));
				user.setPassword(rs.getString("password"));
				user.setAddress(rs.getString("address"));
				user.setMailaddress(rs.getString("mailaddress"));
				userList.add(user);
			}
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {
			//リソースの開放
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
		return userList;
	}
	public void update(User user) {

		Connection con = null;
		Statement smt = null;

		try {
			// 更新用のSQL記述
			String sql = "UPDATE userinfo SET name='" + user.getName() + "'," + " nickname='" + user.getNickname()
			+ "'," + " address='" + user.getAddress() + "'," + "mailaddress='" + user.getMailaddress() + "',"
			+ "password='" + user.getPassword() + "' WHERE userid=" + user.getUserid() + "";

			con = getConnection();
			smt = con.createStatement();

			// データ更新
			int count = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// Statementオブジェクトをクローズ
			// Connectionオブジェクトをクローズ
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}

	}
	// 指定ユーザの情報を取得するメソッド、ユーザー情報詳細を確認時に使用
	public User selectByUser(String userid) {

		Connection con = null;
		Statement smt = null;

		User user = new User();

		String sql = "SELECT * FROM userinfo WHERE userid = " + userid + "";

		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				user.setUserid(rs.getInt("userid"));
				user.setName(rs.getString("password"));
				user.setNickname(rs.getString("nickname"));
				user.setPassword(rs.getString("password"));
				user.setAddress(rs.getString("address"));
				user.setMailaddress(rs.getString("mailaddress"));
			}

		} catch (SQLException e) {
			System.out.println("Errorが発生しました" + e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return user;
	}
	public void delete(int userid) {

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//SQL文
		String sql = "DELETE FROM userinfo WHERE userid = '"+ userid +"'";

		try {

			con = getConnection();
			smt = con.createStatement();

			//SQL文を発行
			smt.executeUpdate(sql);

		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {
			//リソースの開放
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
	}
	public void insert(User user) {

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//SQL文
		String sql =  "INSERT INTO userinfo VALUES("+user.getUserid()+",'"+user.getName()+"','"+user.getNickname()+"','"+user.getPassword()+"','"+user.getAddress()+"','"+user.getMailaddress()+"')";

		try {

			con = getConnection();
			smt = con.createStatement();

			//SQLをDBへ発行
			smt.executeUpdate(sql);

		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {
			//リソースの開放
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
	}
	public ArrayList<User> search(int userid, String name, String nickname,String password,String address,String mailaddress) {

		Connection con = null;
		Statement smt = null;

		ArrayList<User> userList = new ArrayList<User>();
		try {

			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT userid,name,nickname,password,address,mailaddress FROM userinfo "
					+ "WHERE userid LIKE'%" + userid + "%'AND name LIKE'%"
					+ name + "%'AND nickname LIKE'%" + nickname + "%' AND password LIKE'%"
					+password+"%'AND address LIKE'%"+ address+"%'AND mailaddress LIKE'%"+address+"%'";
			ResultSet rs = smt.executeQuery(sql);
			while (rs.next()) {
				User user = new User();
				user.setUserid(rs.getInt("userid"));
				user.setName(rs.getString("name"));
				user.setNickname(rs.getString("nickname"));
				user.setPassword(rs.getString("password"));
				user.setAddress(rs.getString("address"));
				user.setMailaddress(rs.getString("mailaddress"));
				userList.add(user);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return userList;
	}

}



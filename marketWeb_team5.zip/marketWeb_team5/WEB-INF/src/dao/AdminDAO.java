package dao;

import java.sql.*;

import bean.Admin;
import java.util.*;

public class AdminDAO {

	// 接続用の情報をフィールドに定数として定義
	public static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	public static String URL = "jdbc:mysql://localhost/fleadb";
	public static String USER = "root";
	public static String PASSWD = "root123";

	// データベースに接続するメソッド
	private static Connection getConnection(){
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// 指定ユーザとパスワードの条件に合致する情報を取得するメソッド
	public Admin selectByAdmin(String name ,String password) {

		Connection con = null;
		Statement smt = null;

		Admin admin = new Admin();

		String sql = "SELECT * FROM admininfo WHERE name = '" + name + "' AND password='" + password + "'";

		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()) {
				admin.setAdminid(rs.getInt("adminid"));
				admin.setName(rs.getString("name"));;
				admin.setPassword(rs.getString("password"));
			}

		}catch(SQLException e) {
			System.out.println("Errorが発生しました" + e);
		}finally {
			if (smt != null) {
				try {smt.close();}catch(SQLException ignore){}
			}
			if (con != null) {
				try {con.close();}catch(SQLException ignore){}
			}
		}
		return admin;
	}
}

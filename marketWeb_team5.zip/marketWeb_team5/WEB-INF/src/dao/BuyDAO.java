package dao;

import java.sql.*;
import java.util.ArrayList;
import bean.Buy;

public class BuyDAO {

	// 接続用の情報をフィールドに定数として定義
	public static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	public static String URL = "jdbc:mysql://localhost/fleadb";
	public static String buy = "root";
	public static String PASSWD = "root123";

	// データベースに接続するメソッド
	private static Connection getConnection(){
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, buy, PASSWD);
			return con;
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}
	}


	//データベースから全てのアカウント情報の検索を行うメソッド
	//戻り値としてArrayList<buy>型の変数を利用
	public ArrayList<Buy>selectAll(){

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//return用オブジェクトの作成
		ArrayList<Buy> buyList = new ArrayList<Buy>();

		//SQL文
		String sql = "SELECT * FROM buyinfo ORDER BY buyid";

		try {

			con = getConnection();
			smt = con.createStatement();

			//SQLをDBへ発行
			ResultSet rs = smt.executeQuery(sql);

			//検索結果を配列に格納
			while(rs.next()) {
				Buy buy = new Buy();
				buy.setBuyid(rs.getInt("buyid"));
				buy.setBuyerid(rs.getInt("buyerid"));
				buy.setSellid(rs.getInt("sellid"));
				buy.setBuydate(rs.getDate("buydate"));
				buy.setStatus(rs.getInt("status"));
				buy.setPaystatus(rs.getInt("paystatus"));
				buy.setSendstatus(rs.getInt("sendstatus"));
				buyList.add(buy);
			}
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {
			//リソースの開放
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
		return buyList;
	}
	// 購入処理を行うメソッド(update文で上書き)
	public void buy(int sellid, int userid) {

		// オブジェクト作成
		Connection con = null;
		Statement smt = null;

		// SQL文 sellIDを検索条件として、購入IDをユーザーIDにする・取引状況を2にする・※購入日を更新する
		String sql = "UPDATE buyinfo SET buyerid ="  + userid + ", status = 2 WHERE sellid =" +sellid + ";";

		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");

		try {
			// オブジェクト作成
			con = getConnection();
			smt = con.createStatement();

			// SQL発行
			smt.executeUpdate(sql);

		} catch(SQLException e) {
			throw new IllegalStateException(e);

		}finally {
			if (smt != null) {
				try {smt.close();}catch(SQLException ignore){}
			}
			if (con != null) {
				try {con.close();}catch(SQLException ignore){}
			}
		}
	}
}

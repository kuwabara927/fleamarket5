package dao;

import java.sql.*;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;

import bean.Sell;
import bean.Sell;

public class SellDAO {

	// 接続用の情報をフィールドに定数として定義
	public static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	public static String URL = "jdbc:mysql://localhost/fleadb";
	public static String USER = "root";
	public static String PASSWD = "root123";

	// データベースに接続するメソッド
	private static Connection getConnection(){
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// データベースから書籍データを検索しArrayListオブジェクトに格納するメソッド
	public ArrayList<Sell> selectAll(){

		Connection con = null;
		Statement smt = null;

		ArrayList<Sell> list = new ArrayList<Sell>();

		String sql = "SELECT * FROM sellinfo";

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");

		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()) {
				Sell objDto = new Sell();
				objDto.setSellid(rs.getInt("sellid"));
				objDto.setSellerid(rs.getInt("sellerid"));
				objDto.setItemname(rs.getString("itemname"));
				objDto.setCategoryid(rs.getInt("categoryid"));
				objDto.setQuantity(rs.getInt("quantity"));
				objDto.setPrice(rs.getInt("price"));
				objDto.setRemarks(rs.getString("remarks"));
				objDto.setSelldate(rs.getDate("selldate"));
				list.add(objDto);
			}

		}catch(SQLException e) {
			throw new IllegalStateException(e);
		}finally {
			if (smt != null) {
				try {smt.close();}catch(SQLException ignore){}
			}
			if (con != null) {
				try {con.close();}catch(SQLException ignore){}
			}
		}
		return list;
	}

	public ArrayList<Sell> search(String userid,String status) {

		Connection con = null;
		Statement smt = null;

		ArrayList<Sell> list = new ArrayList<Sell>();

		String sql = "SELECT * FROM sellinfo INNER JOIN buyinfo ON "
				+ "sellinfo.sellid = buyinfo.sellid WHERE sellerid = " + userid + " AND status = " + status + ";";

		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()) {
				Sell objDto = new Sell();
				objDto.setSellid(rs.getInt("sellid"));
				objDto.setSellerid(rs.getInt("sellerid"));
				objDto.setItemname(rs.getString("itemname"));
				objDto.setCategoryid(rs.getInt("categoryid"));
				objDto.setQuantity(rs.getInt("quantity"));
				objDto.setPrice(rs.getInt("price"));
				objDto.setRemarks(rs.getString("remarks"));
				objDto.setSelldate(rs.getDate("selldate"));
				list.add(objDto);
			}

		}catch(SQLException e) {
			throw new IllegalStateException(e);
		}finally {
			if (smt != null) {
				try {smt.close();}catch(SQLException ignore){}
			}
			if (con != null) {
				try {con.close();}catch(SQLException ignore){}
			}
		}
		return list;
	}
	public ArrayList<Sell> selectByUserid(int userid) {

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//return用オブジェクトの作成
		ArrayList<Sell> list= new ArrayList<Sell>();

		//SQL文
		String sql = "SELECT * FROM sellinfo WHERE sellerid = '" + userid + "'";

		try {

			con = getConnection();
			smt = con.createStatement();

			//SQL文を発行
			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()) {
				Sell sell = new Sell();
				sell.setSellid(rs.getInt("sellid"));
				sell.setSellerid(rs.getInt("sellerid"));
				sell.setItemname(rs.getString("itemname"));
				sell.setCategoryid(rs.getInt("categoryid"));
				sell.setQuantity(rs.getInt("quantity"));
				sell.setPrice(rs.getInt("price"));
				sell.setRemarks(rs.getString("remarks"));
				sell.setSelldate(rs.getDate("selldate"));
				list.add(sell);
			}
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {
			//リソースの開放
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
		return list;
	}
	public Sell selectBySellid(int sellid) {

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//return用オブジェクトの作成
		Sell sell = new Sell();

		//SQL文
		String sql = "SELECT * FROM sellinfo WHERE sellid = '" + sellid + "'";

		try {

			con = getConnection();
			smt = con.createStatement();

			//SQL文を発行
			ResultSet rs = smt.executeQuery(sql);

			if(rs.next()) {
				sell.setSellid(rs.getInt("sellid"));
				sell.setSellerid(rs.getInt("sellerid"));
				sell.setItemname(rs.getString("itemname"));
				sell.setCategoryid(rs.getInt("category"));
				sell.setQuantity(rs.getInt("quantity"));
				sell.setPrice(rs.getInt("price"));
				sell.setRemarks(rs.getString("remarks"));
				sell.setSelldate(rs.getDate("selldate"));
			}
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {
			//リソースの開放
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
		return sell;
	}
	public void delete(int sellid) {

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//SQL文
		String sql = "DELETE FROM sellinfo WHERE sellid = '"+ sellid +"'";

		try {

			con = getConnection();
			smt = con.createStatement();

			//SQL文
			smt.executeQuery(sql);

		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {
			//リソースの開放
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
	}
	public int total(int month){

		Connection con = null;
		Statement smt = null;

		//売上総額を格納する変数を宣言
		int total = 0;

		String sql = "SELECT SUM(price) FROM sellinfo WHERE DATE_FORMAT(selldate, '%m')='0" + month + "'" ;

		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			//売上総額を取得し変数totalに格納
			if(rs.next()) {
				total = rs.getInt("SUM(price)");
			}

		}catch(SQLException e) {
			throw new IllegalStateException(e);
		}finally {
			if (smt != null) {
				try {smt.close();}catch(SQLException ignore){}
			}
			if (con != null) {
				try {con.close();}catch(SQLException ignore){}
			}
		}
		return total;
	}

	// データベースからログインユーザーの購入済み商品データを検索しArrayListオブジェクトに格納するメソッド
	public ArrayList<Sell> selectPurchase(int userid) {

		Connection con = null;
		Statement smt = null;

		ArrayList<Sell> list = new ArrayList<Sell>();

		String sql = "SELECT * FROM sellinfo INNER JOIN buyinfo ON sellinfo.sellid = buyinfo.sellid  WHERE status = 3 AND buyerid =" +  userid + ";";

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");

		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()) {
				Sell objDto = new Sell();
				objDto.setSellid(rs.getInt("sellid"));
				objDto.setSellerid(rs.getInt("sellerid"));
				objDto.setItemname(rs.getString("itemname"));
				objDto.setCategoryid(rs.getInt("categoryid"));
				objDto.setQuantity(rs.getInt("quantity"));
				objDto.setPrice(rs.getInt("price"));
				objDto.setRemarks(rs.getString("remarks"));
				objDto.setSelldate(rs.getDate("selldate"));
				list.add(objDto);
			}

		}catch(SQLException e) {
			throw new IllegalStateException(e);

		}finally {
			if (smt != null) {
				try {smt.close();}catch(SQLException ignore){}
			}
			if (con != null) {
				try {con.close();}catch(SQLException ignore){}
			}
		}
		return list;
	}

	public void insert(Sell sell) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "INSERT INTO sellinfo(itemname,categoryid,quantity,price,remarks) VALUES('"
					+ sell.getItemname() + "',"
					+ sell.getCategoryid() + ","
					+ sell.getQuantity() + ","
					+ sell.getPrice() + ",'"
					+ sell.getRemarks() + "')";
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

}

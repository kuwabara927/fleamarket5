package dao;

import java.sql.*;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;

import bean.Sell;

public class SellDAO {

	// 接続用の情報をフィールドに定数として定義
	public static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	public static String URL = "jdbc:mysql://localhost/fleadb";
	public static String USER = "root";
	public static String PASSWD = "root123";

	// データベースに接続するメソッド
	private static Connection getConnection(){
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// データベースから書籍データを検索しArrayListオブジェクトに格納するメソッド
	public ArrayList<Sell> selectAll(){

		Connection con = null;
		Statement smt = null;

		ArrayList<Sell> list = new ArrayList<Sell>();

		String sql = "SELECT * FROM sellinfo";

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");

		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()) {
				Sell objDto = new Sell();
				objDto.setSellid(rs.getInt("sellid"));
				objDto.setSellerid(rs.getInt("sellerid"));
				objDto.setItemname(rs.getString("itemname"));
				objDto.setCategoryid(rs.getInt("categoryid"));
				objDto.setQuantity(rs.getInt("quantity"));
				objDto.setPrice(rs.getInt("price"));
				objDto.setRemarks(rs.getString("remarks"));
				objDto.setSelldate(rs.getDate("selldate"));
				list.add(objDto);
			}

		}catch(SQLException e) {
			throw new IllegalStateException(e);
		}finally {
			if (smt != null) {
				try {smt.close();}catch(SQLException ignore){}
			}
			if (con != null) {
				try {con.close();}catch(SQLException ignore){}
			}
		}
		return list;
	}



}

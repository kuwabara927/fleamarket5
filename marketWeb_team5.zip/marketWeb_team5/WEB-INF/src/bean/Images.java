package bean;

public class Images {

	private int imageid; // 画像ID
	private String imagepath; // ファイルパス
	private int sellid; // 出品ID

	//コンストラクタ
	public Images() {
		this.imageid = 0;
		this.imagepath = null;
		this.sellid = 0;
	}

	//ゲッター、セッターメソッド呼出
	public int getImageid() {
		return imageid;
	}
	public void setImageid(int imageid) {
		this.imageid = imageid;
	}

	public String getImagepath() {
		return imagepath;
	}
	public void setImagepath(String imagepath) {
		this.imagepath = imagepath;
	}

	public int getSellid() {
		return sellid;
	}
	public void setSellid(int sellid) {
		this.sellid = sellid;
	}

}
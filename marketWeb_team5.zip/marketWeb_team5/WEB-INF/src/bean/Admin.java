package bean;

public class Admin {

	private int adminid; // 管理者ID
	private String name; // 管理者名
	private String password; // パスワード

	// コンストラクタ
	public Admin() {
		this.adminid = 0;
		this.name = null;
		this.password = null;
	}

	// アクセサメソッド
	public int getAdminid() {
		return adminid;
	}

	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

}
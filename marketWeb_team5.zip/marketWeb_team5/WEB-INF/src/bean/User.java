package bean;

public class User {

	private int userid; // ユーザーID
	private String name; // 本名
	private String nickname; // ニックネーム
	private String password; // パスワード
	private String address; // 住所
	private String mailaddress; // メールアドレス


	//コンストラクタ
	public User() {
		this.userid = 0;
		this.name = null;
		this.nickname = null;
		this.password = null;
		this.address = null;
		this.mailaddress = null;
	}

	//ゲッター、セッターメソッド呼出
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public String getMailaddress() {
		return mailaddress;
	}
	public void setMailaddress(String mailaddress) {
		this.mailaddress = mailaddress;
	}

}
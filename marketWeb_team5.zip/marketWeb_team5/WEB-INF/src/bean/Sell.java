package bean;
import java.util.Date;

public class Sell {

	private int sellid; // 出品ID
	private int sellerid; // 出品者ID
	private String itemname; // 商品名
	private int categoryid; // 種類
	private int quantity; // 個数
	private int price; // 価格
	private String remarks; // 備考
	private Date selldate; // 出品日


	//コンストラクタ
	public Sell() {
		this.sellid = 0;
		this.sellerid = 0;
		this.itemname = null;
		this.categoryid = 0;
		this.quantity = 0;
		this.price = 0;
		this.remarks = null;
		this.selldate = null;
	}

	//ゲッター、セッターメソッド呼出
	public int getSellid() {
		return sellid;
	}
	public void setSellid(int sellid) {
		this.sellid = sellid;
	}

	public int getSellerid() {
		return sellerid;
	}
	public void setSellerid(int sellerid) {
		this.sellerid = sellerid;
	}

	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public int getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}

	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Date getSelldate() {
		return selldate;
	}
	public void setSelldate(Date selldate) {
		this.selldate = selldate;
	}

}
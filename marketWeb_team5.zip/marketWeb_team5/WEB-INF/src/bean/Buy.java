package bean;

public class Buy {

	private int buyid; // 購入ID
	private int buyerid;  // 購入者ID
	private int sellid;  // 出品ID
	private String buydate;  // 購入日 (datetime方式、例:2022-12-01 12:01:00)
	private int status;  // 取引状況（1:未,2:取引中,3:済み）
	private int paystatus;  // 入金状況 （1:未,2:済み）
	private int sendstatus;  // 発送状況（1:未,2:済み）

	// コンストラクタ
	public Buy() {
		this.buyid = 0;
		this.buyerid = 0;
		this.sellid = 0;
		this.buydate = null;
		this.status = 0;
		this.paystatus = 0;
		this.sendstatus = 0;
	}


	// アクセサメソッド
	public int getBuyid() {
		return buyid;
	}

	public void setBuyid(int buyid) {
		this.buyid = buyid;
	}

	public int getBuyerid() {
		return buyerid;
	}

	public void setBuyerid(int buyerid) {
		this.buyerid = buyerid;
	}

	public int getSellid() {
		return sellid;
	}

	public void setSellid(int sellid) {
		this.sellid = sellid;
	}

	public String getBuydate() {
		return buydate;
	}

	public void setBuydate(String buydate) {
		this.buydate = buydate;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getPaystatus() {
		return paystatus;
	}

	public void setPaystatus(int paystatus) {
		this.paystatus = paystatus;
	}

	public int getSendstatus() {
		return sendstatus;
	}

	public void setSendstatus(int sendstatus) {
		this.sendstatus = sendstatus;
	}

}
